# Billwise — Utility Bill Decoder

A Python utility bill decoder with a responsive, modern browser dashboard and a CLI batch mode. Open the whole folder in VS Code; no Node.js or frontend build is needed.

## Important model compatibility

The supplied documents mandate `gemini-1.5-flash` and the old `google-generativeai` SDK. Gemini 1.5 Flash is no longer supported. This project uses Google's maintained **google-genai** SDK and requires you to explicitly configure an available, organizer-approved image-capable model. It never silently substitutes a model. **This is a disclosed deviation from the original specification; organizer approval is needed for submission compliance.** Leaving GEMINI_MODEL empty allows you to view the UI but prevents analysis.

References: https://ai.google.dev/gemini-api/docs/libraries and https://ai.google.dev/gemini-api/docs/deprecations .

## Windows / VS Code setup

1. Extract the ZIP. In VS Code choose **File → Open Folder → utility-bill-decoder**.
2. Install Python 3.11 or newer if needed. Open **Terminal → New Terminal** in the project root.
3. Run these commands (no PowerShell activation policy changes needed):

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

4. Open `.env`, replace `your_api_key_here` with your Google Gemini API key. Keep it private. OpenRouter keys do not work with this project.
5. List available models:

```powershell
.\.venv\Scripts\python.exe source/list_models.py
```

6. Set `GEMINI_MODEL` to an image-capable model permitted by the organizers. Check quota in your Gemini account; this project does not guarantee a free API allowance.
7. Start the dashboard:

```powershell
.\.venv\Scripts\python.exe source/app.py
```

8. Open **http://127.0.0.1:5000** in your browser. Later you can double-click `start_windows.bat`.

macOS/Linux: use `python3 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt`, `cp .env.example .env`, then `.venv/bin/python source/app.py`.

## Use the dashboard

- Select or drag in 1–10 JPEG/PNG bills, up to 10 MB and 25 megapixels each.
- Click **Analyze bills**. Each bill makes one extraction request and twelve individual Q&A requests. Ten bills use 130 requests before retries, so processing can take several minutes or longer depending on your quota.
- Select a processed bill to see consumption, charges, all twelve answers, and source evidence.
- Review uncertain values and errors. Confidence is model-estimated, not a validated accuracy score.
- Download **Level 1 CSV** and **Level 2 CSV**. A fully successful batch of 10 produces 10 extraction rows and 120 answer rows. Failed results are visibly reported and omitted from CSV; they are never replaced with fabricated responses. Missing extracted values remain blank.
- A new batch replaces the previous dashboard results. Download first. Clear session removes dashboard results. Uploaded images are processed in memory and sent to Google; provider data policies apply. Restart clears dashboard memory.

## CLI batch mode

Place your real bills in `sample_bills/`, then:

```powershell
.\.venv\Scripts\python.exe source/main.py
```

Optional: `--input another_folder --output another_output_folder`.
Outputs are overwritten per run, with a checkpoint after each bill: `output/level1.csv`, `output/level2.csv`, `output/report.json`. The JSON includes field evidence, source labels and errors. A nonzero exit code indicates partial or full failure. No append mode is provided, preventing accidental duplicate submissions.

## Project map

- `source/app.py`: local Flask dashboard and CSV downloads
- `source/templates/index.html`, `source/static/`: complete HTML, CSS and JavaScript interface
- `source/main.py`: CLI orchestration
- `source/ai_client.py`: Gemini calls, timeouts, retries and response validation
- `source/extractor.py`: grounded bill extraction
- `source/explainer.py`: 12 separate bill-specific Q&A requests
- `source/models.py`: Pydantic schemas
- `source/utils.py`: safe image decoding and Pandas CSV export
- `source/config.py`: paths, environment loading, exact CSV columns and questions
- `tests/test_app.py`: offline pipeline, API and export checks
- `docs/`: original supplied specification documents (unchanged)

## Accuracy and implementation choices

No OCR service, hardcoded bill values or simulated dashboard results are used. Pillow only decodes and normalizes images. Unknown fields use null, not -1 (negative monetary amounts may be legitimate credits). Unsupported providers become Unknown instead of a guessed provider. Tax adjustments may be negative. Printed total payable is preserved rather than forced to equal base plus taxes, because arrears and credits can change the amount. Savings answers must disclose assumptions and cannot promise savings from tariff data absent on the bill.

The application uses sequential API processing to limit quota pressure. It supports ten uploads per dashboard batch and recursive CLI batches. PDFs, custom chat, accounts, deployment, historical bill storage, and append exports are not implemented. This is a local hackathon application, not a public multi-user production service. The source documents' accuracy, memory and timing targets are not verified guarantees. Dependency ranges are used rather than a falsely claimed reproducible lock; after installing and validating locally, use `python -m pip freeze > requirements-lock.txt` if your submission needs exact environment versions.

## Troubleshooting

- **Configuration missing:** add your key/model to root `.env`; stop and restart Python.
- **404 / model unavailable:** inspect `list_models.py`; ask organizers which current model is allowed.
- **429 / quota:** wait or check Gemini quotas. Retries use exponential delays for transient API status codes.
- **No response / malformed data:** use a sharper full-page image and confirm your model supports image input plus structured JSON.
- **Incomplete CSV:** check per-bill errors. Reprocess the failed bills or the whole batch before final submission.
- **Page not loading:** keep the Python terminal running, then visit the local URL manually.
- **Port occupied:** close the existing app using Ctrl+C, then restart.

## Offline tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Tests use explicit mocked responses, never presented as actual bill analysis. Live extraction requires your key and actual bills. No actual sample bill images, generated result CSVs, or screen recording were supplied or invented. Add your real bills, run analysis and record the demo before submitting.
