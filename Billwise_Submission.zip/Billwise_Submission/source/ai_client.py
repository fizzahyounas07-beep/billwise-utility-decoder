"""Only real Gemini responses enter the extraction pipeline."""
import time
from config import settings
class Gemini:
    def __init__(self):
        from google import genai
        from google.genai import types
        key, self.model = settings()
        self.types = types
        self.client = genai.Client(api_key=key, http_options=types.HttpOptions(timeout=60000))
    def ask(self, image, prompt, schema):
        data, mime = image
        for attempt in range(3):
            try:
                response = self.client.models.generate_content(
                    model=self.model,
                    contents=[prompt, self.types.Part.from_bytes(data=data,mime_type=mime)],
                    config={'response_mime_type':'application/json','response_json_schema':schema.model_json_schema()})
                if not response.text:
                    raise ValueError('AI returned no readable response. Try a clearer bill image.')
                return schema.model_validate_json(response.text)
            except Exception as exc:
                code = getattr(exc,'code',None)
                if code in (429,500,502,503,504) and attempt < 2:
                    time.sleep(2 ** (attempt+1))
                    continue
                if code in (401,403):
                    raise ValueError('API access denied. Check your Gemini key and account permissions.') from None
                if code == 404:
                    raise ValueError('Configured model is unavailable. Set an available, organizer-approved GEMINI_MODEL in .env and restart.') from None
                if code == 429:
                    raise ValueError('Gemini quota exceeded. Wait and retry, or check your account quota.') from None
                if code:
                    raise ValueError(f'Gemini request failed (HTTP {code}). Check model access and try again.') from None
                raise ValueError('AI request or response validation failed. Check connectivity, model support and image quality.') from None
    def close(self):
        self.client.close()
