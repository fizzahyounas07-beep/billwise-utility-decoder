"""Local-only dashboard; results live in memory until restart or Clear session."""
import copy, io, os, secrets, threading
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, request, jsonify, render_template, send_file
from config import LEVEL1, LEVEL2, settings
from ai_client import Gemini
from pipeline import process_bill
from utils import load_image_safely, csv_bytes
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 105 * 1024 * 1024
TOKEN = secrets.token_urlsafe(32)
lock = threading.Lock()
executor = ThreadPoolExecutor(max_workers=1)
state = {'busy':False,'message':'Ready for your bills','completed':0,'total':0,'results':[]}

@app.before_request
def guard():
    if request.host.split(':')[0] not in ('127.0.0.1','localhost'):
        return jsonify(error='This app is available on localhost only.'),403
    if request.path.startswith('/api/') and request.headers.get('X-App-Token') != TOKEN:
        return jsonify(error='Reload the page to reconnect.'),403

@app.after_request
def headers(response):
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'"
    return response

@app.errorhandler(413)
def too_large(error):
    return jsonify(error='Upload is too large. Choose up to 10 images, each under 10 MB.'),413

@app.get('/')
def index():
    return render_template('index.html', token=TOKEN)

@app.get('/api/status')
def status():
    with lock:
        snapshot=copy.deepcopy(state)
    try:
        _,snapshot['model']=settings()
        snapshot['configured']=True
    except ValueError as exc:
        snapshot.update(configured=False,configuration_error=str(exc),model='Not configured')
    return jsonify(snapshot)

def run_batch(files):
    client=None
    try:
        client=Gemini()
        for filename,data in files:
            def progress(message):
                with lock:
                    state['message']=f'{filename} · {message}'
            result=process_bill(client,data,filename,progress)
            with lock:
                state['results'].append(result)
                state['completed']+=1
        with lock:
            state['message']='Processing finished. Review any reported errors before exporting.'
    except Exception:
        with lock:
            state['message']='Processing could not start. Check dependencies, API configuration and connection.'
    finally:
        if client:
            try: client.close()
            except Exception: pass
        with lock:
            state['busy']=False

@app.post('/api/analyze')
def analyze():
    try:
        settings()
        incoming=request.files.getlist('bills')
        if not 1 <= len(incoming) <= 10:
            raise ValueError('Choose between 1 and 10 bill images.')
        files=[]
        names=set()
        for item in incoming:
            filename=(item.filename or 'bill').replace('\\','/').split('/')[-1]
            if filename in names:
                raise ValueError('Duplicate filenames: rename the images so each name is unique.')
            names.add(filename)
            data=item.read(10*1024*1024+1)
            load_image_safely(data)
            files.append((filename,data))
        with lock:
            if state['busy']:
                return jsonify(error='A batch is already processing.'),409
            state.update(busy=True,message='Starting analysis',completed=0,total=len(files),results=[])
        executor.submit(run_batch,files)
        return jsonify(ok=True),202
    except ValueError as exc:
        return jsonify(error=str(exc)),400

@app.post('/api/clear')
def clear():
    with lock:
        if state['busy']:
            return jsonify(error='Wait for processing to finish before clearing.'),409
        state.update(results=[],completed=0,total=0,message='Ready for your bills')
    return jsonify(ok=True)

@app.get('/api/export/<level>')
def export(level):
    if level not in ('level1','level2'):
        return jsonify(error='Unknown export.'),404
    with lock:
        if state['busy']:
            return jsonify(error='Wait for processing to finish.'),409
        results=copy.deepcopy(state['results'])
    rows=([r['extraction'] for r in results if r['extraction']] if level=='level1'
          else [q for r in results for q in r['answers']])
    if not rows:
        return jsonify(error='There are no successful results to export.'),400
    return send_file(io.BytesIO(csv_bytes(rows,LEVEL1 if level=='level1' else LEVEL2)),
                     mimetype='text/csv',as_attachment=True,download_name=f'{level}.csv')

if __name__=='__main__':
    app.run(host='127.0.0.1',port=5000,debug=False)
