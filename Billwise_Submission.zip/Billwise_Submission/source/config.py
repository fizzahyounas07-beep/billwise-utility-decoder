from pathlib import Path
import os
from dotenv import load_dotenv
ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env')
load_dotenv(ROOT / 'source' / '.env')
QUESTIONS = dict(zip([f'Q{i:02}' for i in range(1,13)], [
'What is the billing period for this electricity bill?',
'Which utility company issued this bill?',
'How many units of electricity were consumed?',
'What are the base electricity charges?',
'What is the total amount of taxes and adjustments?',
'What is the final total amount payable?',
'How is the electricity tariff structured for this consumer?',
'What taxes and surcharges are included in this bill?',
'Is there any arrears or previous amount due?',
'What is the payment due date?',
'How much would a 10% reduction in consumption save?',
'What are any special notes or advisory messages on the bill?']))
FIELDS = ['utility_company','billing_period','units_consumed','electricity_charges','taxes_and_adjustments','total_payable_amount']
LEVEL1 = ['file_name', *FIELDS, 'extraction_confidence','extraction_timestamp']
LEVEL2 = ['file_name','question_id','question_text','answer_text','answer_confidence','answer_timestamp']
def settings():
    key = os.getenv('GEMINI_API_KEY','').strip()
    model = os.getenv('GEMINI_MODEL','').strip()
    if not key or key == 'your_api_key_here':
        raise ValueError('Add GEMINI_API_KEY to .env, then restart the app.')
    if not model:
        raise ValueError('Set GEMINI_MODEL in .env to an available, organizer-approved vision model. See README.')
    return key, model
