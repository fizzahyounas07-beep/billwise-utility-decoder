import os
from config import ROOT
from google import genai
key=os.getenv('GEMINI_API_KEY','').strip()
if not key or key=='your_api_key_here':
    raise SystemExit('Set GEMINI_API_KEY in the root .env file first.')
with genai.Client(api_key=key) as client:
    for model in client.models.list():
        if 'generateContent' in (model.supported_actions or []):
            print(model.name.removeprefix('models/'))
print('Choose an image-capable model permitted by your organizers; availability does not imply permission or free quota.')
