"""CLI batch entry point. Run from any working directory."""
import argparse, json
from config import ROOT
from ai_client import Gemini
from pipeline import process_bill
from utils import export_results

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', default=str(ROOT/'sample_bills'))
    parser.add_argument('--output', default=str(ROOT/'output'))
    args = parser.parse_args()
    from pathlib import Path
    paths = sorted(p for p in Path(args.input).rglob('*') if p.suffix.lower() in ('.jpg','.jpeg','.png'))
    if not paths:
        parser.error('No JPEG/PNG bills found. Add bills to sample_bills/.')
    client = Gemini()
    results=[]
    try:
        for i,path in enumerate(paths,1):
            name = path.relative_to(args.input).as_posix()
            print(f'[{i}/{len(paths)}] {name}')
            results.append(process_bill(client,path.read_bytes(),name,print))
            export_results(results,args.output)
        (Path(args.output)/'report.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    finally:
        client.close()
    failed = sum(bool(r['errors']) for r in results)
    print(f'Finished: {len(results)} bills, {failed} with errors. Outputs: {args.output}')
    return 1 if failed else 0
if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except ValueError as exc:
        raise SystemExit(str(exc))
