from typing import Literal
from pydantic import BaseModel, Field, ConfigDict
class StrictModel(BaseModel):
    model_config = ConfigDict(allow_inf_nan=False)
class Evidence(StrictModel):
    field: str
    confidence: float = Field(ge=0,le=1)
    source: str
class Extraction(StrictModel):
    utility_company: Literal['IESCO','LESCO','K-Electric','Unknown']
    billing_period: str | None
    units_consumed: float | None
    electricity_charges: float | None
    taxes_and_adjustments: float | None
    total_payable_amount: float | None
    extraction_confidence: float = Field(ge=0,le=1)
    evidence: list[Evidence]
    notes: list[str]
class Answer(StrictModel):
    answer_text: str = Field(min_length=1)
    answer_confidence: float = Field(ge=0,le=1)
    source: str
