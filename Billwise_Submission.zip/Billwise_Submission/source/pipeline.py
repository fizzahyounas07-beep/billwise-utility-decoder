from pathlib import Path
from config import QUESTIONS
from extractor import extract_bill_data
from explainer import answer_question
from utils import load_image_safely, now

def process_bill(client, data, filename, progress=lambda message:None):
    result = {'file_name':filename,'extraction':None,'answers':[],'errors':[]}
    try:
        image = load_image_safely(data)
        progress('Extracting bill details')
        result['extraction'] = {**extract_bill_data(client,image),'file_name':filename,'extraction_timestamp':now()}
    except Exception as exc:
        result['errors'].append(str(exc))
        return result
    for qid, question in QUESTIONS.items():
        progress(f'Answering {qid} of Q12')
        try:
            answer = answer_question(client,image,qid)
            result['answers'].append({**answer,'file_name':filename,'question_id':qid,
                                      'question_text':question,'answer_timestamp':now()})
        except Exception as exc:
            result['errors'].append(f'{qid}: {exc}')
    return result
