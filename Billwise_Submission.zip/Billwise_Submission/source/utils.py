import io, csv, warnings
from pathlib import Path
from datetime import datetime, timezone
from PIL import Image, ImageOps
import pandas as pd
from config import LEVEL1, LEVEL2

def now():
    return datetime.now(timezone.utc).isoformat()

def load_image_safely(data):
    if len(data) > 10 * 1024 * 1024:
        raise ValueError('Each image must be smaller than 10 MB.')
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error',Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(data)) as im:
                if im.format not in ('JPEG','PNG'):
                    raise ValueError('Only JPEG and PNG images are supported.')
                if im.width * im.height > 25_000_000:
                    raise ValueError('Image exceeds 25 megapixels. Resize it first.')
                im.load()
                im = ImageOps.exif_transpose(im).convert('RGB')
                out = io.BytesIO()
                im.save(out,format='JPEG',quality=95)
                return out.getvalue(), 'image/jpeg'
    except ValueError:
        raise
    except Exception:
        raise ValueError('This file is not a readable JPEG or PNG image.') from None

def csv_bytes(rows, columns):
    # Neutralize spreadsheet formulas in untrusted filenames and AI text.
    def safe(value):
        if isinstance(value,str) and value.lstrip().startswith(('=','+','-','@','\t','\r')):
            return "'"+value
        return value
    frame = pd.DataFrame(rows, columns=columns)
    for col in frame.columns:
        frame[col] = frame[col].map(safe)
    return frame.to_csv(index=False,lineterminator='\r\n',quoting=csv.QUOTE_MINIMAL).encode('utf-8-sig')

def export_results(results, output):
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    for level, cols, rows in [('level1',LEVEL1,[r['extraction'] for r in results if r['extraction']]),
                              ('level2',LEVEL2,[q for r in results for q in r['answers']])]:
        path = output / f'{level}.csv'
        temporary = path.with_suffix('.tmp')
        temporary.write_bytes(csv_bytes(rows,cols))
        temporary.replace(path)
